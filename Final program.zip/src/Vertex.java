 
public class Vertex {
	int BackNum = -1;
	int position = -1;
	
	
	String name = "";
	
	
	
	
	
	
	
	
	
	Vertex(int Backnum ,String name ,int position){
		this.BackNum= Backnum;
		
		
		this.name = name;
		
		this.position = position;
		
	}

}
