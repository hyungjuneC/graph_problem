import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class InfoGet {
	
	
	static Scanner s;
	
	public static double[][] avHitarr = new double[25][9];
	
	public static double[][] OPSarr= new double[25][9];
	
	public static double[][] WPAarr= new double[25][9];
	
	public static String[] battername = new String[25];
	
	public static int[] batterposition = new int[25];
	
	
	public void getinformation() {
		int count = 0;
		File inputfile = new File("battersinfo.txt");
		try {
			s = new Scanner(inputfile);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		while(s.hasNextLine()) {
			
			String infostr = s.nextLine();
			
			String[] infos = infostr.split(",");
			
			battername[count] = infos[0];
			
			batterposition[count] = Integer.parseInt( infos[1]);
			
			
			
			
			
			for(int i =0; i< 9; i++) {

				avHitarr[count][i]= Double.parseDouble(infos[(i*3)+2]);
				OPSarr[count][i]=Double.parseDouble(infos[(i*3)+3]);
				WPAarr[count][i]=Double.parseDouble(infos[(i*3)+4]);
			
			}
			
			
			count++;
			
			
		}
		
	}
	
	public static void main(String[] args) {
		
		int count = 0;
		File inputfile = new File("battersinfo.txt");
		try {
			s = new Scanner(inputfile);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		while(s.hasNextLine()) {
			
			String infostr = s.nextLine();
			
			String[] infos = infostr.split(",");
			
			battername[count] = infos[0];
			
			batterposition[count] = Integer.parseInt( infos[1]);
			
			
			
			
			
			for(int i =0; i< 9; i++) {
			avHitarr[count][i]= Double.parseDouble(infos[(i*3)+2]);
			OPSarr[count][i]=Double.parseDouble(infos[(i*3)+3]);
			WPAarr[count][i]=Double.parseDouble(infos[(i*3)+4]);
			
			System.out.println(battername[count]+":"+batterposition[count]+","+avHitarr[count][i]+","+OPSarr[count][i]+","+WPAarr[count][i]);
			}
			
			
			count++;
			
			
		}
	}

}
