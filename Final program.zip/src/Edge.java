
public class Edge {
	
	
	 public double getWeight1() {
		return Weight1;
	}


	public void setWeight1(double weight1) {
		Weight1 = weight1;
	}


	public double getWeight2() {
		return Weight2;
	}


	public void setWeight2(double weight2) {
		Weight2 = weight2;
	}


	public double getWeight3() {
		return Weight3;
	}


	public void setWeight3(double weight3) {
		Weight3 = weight3;
	}

	double Weight1;
	
	 double Weight2;
	
	 double Weight3;
	 
	 boolean selected = false;
	
	
	
	Vertex from;
	
	Vertex to;
	
	
	Edge(double avHit, double OPS, double WPA){
		this.Weight1=avHit;
		this.Weight2= OPS;
		this.Weight3= WPA;
	}
	
	
	public void setConnection(Vertex from, Vertex to) {
		
		this.from = from;
		
		this. to = to;
	}
	
	public Vertex getDestination() {
		return to;
	}
	
	public boolean getselected() {
		return selected;
	}
	public void select() {
		selected=true;
	}

}
