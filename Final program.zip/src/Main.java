import java.util.Scanner;

public class Main {
	
	static Crawling  crawlmodule = new Crawling();
	static boolean crawlFlag = false;
	static InfoGet infoget = new InfoGet();
	static Vertex[] batters = new Vertex[25];
	static Vertex[] StartMember = new Vertex[9];
	static Edge[][] edges = new Edge[25][25];
	static int[] selectedposition = new int[9];
	static int OppoTeam;
	static int data;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		Scanner s = new Scanner(System.in);
		
		for(int k = 0; k<9;k++) {
			selectedposition[k]=-1;
			
		}
		
		
		System.out.println("ũ�Ѹ��� �ؼ� ������ �����Ͻðڽ��ϱ�?(true:����,false:�������� ����)");
		crawlFlag=s.nextBoolean();
		//get information of batters
		if(crawlFlag==false){
			infoget.getinformation();
			
			for(int i = 0; i<25; i++) {
			batters[i] = new Vertex(i,infoget.battername[i],infoget.batterposition[i]);
			
			
			}
			while(true) {
			System.out.println("������� ��������� �˷��ֽʽÿ�.(0:���,1:KT,2:LG,3:NC,4:SK,5:�ؼ�,6:�λ�,7:�Ե�,8:�Ｚ)");
			 OppoTeam = s.nextInt();
			
			
			if(OppoTeam >8) {
				System.out.println("8�� �ȿ����� ������ ����ֽʽÿ�");
				OppoTeam = s.nextInt();
				break;
				
			}
			else {
				break;
			}
			}
			
			for(int i = 0; i< 25; i++) {
				for(int j = 0; j<25; j++) {
					edges[i][j]= new Edge(infoget.avHitarr[i][OppoTeam],infoget.OPSarr[i][OppoTeam],infoget.WPAarr[i][OppoTeam]);
					
					
					if(batters[i].position==batters[j].position) {
							edges[i][j].setConnection(batters[i], null);
						
					}
					else {
							edges[i][j].setConnection(batters[i], batters[j]);
					}
					
					
				}
			}
			
			
		  for(int p = 0; p< 9; p++) {
			  while(true) {
			  System.out.println((p+1)+"�� Ÿ�ڸ� ���� ���� �켱�ؾ� �� �����͸� �˷��ֽʽÿ�(1:�����,2:OPS,3:WPA)");
			  data = s.nextInt();
			  
			  if(data>3&&data<1) {
				  System.out.println("1,2,3�� ���� ���ڸ� �Է����ֽʽÿ�");
				  data=s.nextInt();
				  break;
			  }
			  else {
				  break;
			  }
			  
			  
			  }
			  if(data==1) {
				  double MaxavHit = 0.0;
				  int selectednum = -1;
				  for(int f = 0; f<25; f++) {
					  
						  if(selectedposition[batters[f].position]==-1) {
							  if(MaxavHit<edges[f][0].getWeight1()) {
								  MaxavHit = edges[f][0].getWeight1();
								  selectednum = f;
							  }
						  
						  
					  }
						
						
				  }
				  
				  StartMember[p]=batters[selectednum];
				  selectedposition[batters[selectednum].position]=1;
				  for(int f = 0; f<25; f++) {
					  
					  if(selectedposition[batters[f].position]==-1) {
						System.out.print("B ");
					  
					  
				  }
					  else if(selectednum ==f) {
						  System.out.print("S ");
					  }
					  else {
						  System.out.print("  ");
					  }
					if((f+1)%5==0) {
						System.out.println();
					}
					
			  }
				
				  
				  
			  }
			  else if(data==2) {
				  double OPS = 0.0;
				  int selectednum = -1;
				  for(int f = 0; f<25; f++) {
					  
						  if(selectedposition[batters[f].position]==-1) {
							  if(OPS<edges[f][0].getWeight2()) {
								  OPS = edges[f][0].getWeight2();
								  selectednum = f;
							  }
						  
						  
					  }
						
						
				  }
				  
				  StartMember[p]=batters[selectednum];
				  selectedposition[batters[selectednum].position]=1;
				  for(int f = 0; f<25; f++) {
					  
					  if(selectedposition[batters[f].position]==-1) {
						System.out.print("B ");
					  
					  
				  }
					  else if(selectednum ==f) {
						  System.out.print("S ");
					  }
					  else {
						  System.out.print("  ");
					  }
					if((f+1)%5==0) {
						System.out.println();
					}
					
			  }
				
				  
				  
			  }
			  else if(data==3) {
				  double WPA = -100.0;
				  int selectednum = -1;
				  for(int f = 0; f<25; f++) {
					  
						  if(selectedposition[batters[f].position]==-1) {
							  if(WPA<edges[f][0].getWeight3()) {
								  WPA = edges[f][0].getWeight3();
								  selectednum = f;
							  }
						  
						  
					  }
						
						
				  }
				  
				  StartMember[p]=batters[selectednum];
				  selectedposition[batters[selectednum].position]=1;
				  for(int f = 0; f<25; f++) {
					  
					  if(selectedposition[batters[f].position]==-1) {
						System.out.print("B ");
					  
					  
				  }
					  else if(selectednum ==f) {
						  System.out.print("S ");
					  }
					  else {
						  System.out.print("  ");
					  }
					if((f+1)%5==0) {
						System.out.println();
					}
					
			  }
				  
			  }
			
		  }
		  
		
		  System.out.println("| ���ȣ | ���� �̸� | ���� ������ |");
		  
		  for(int j = 0; j<9; j++) {
			  String positionName = null;
			  switch(StartMember[j].position) {
			  case 0:
				  positionName = "����";
				  break;
			  case 1:
				  positionName = "1���";
				  break;
			  case 2:
				  positionName = "2���";
				  break;
			  case 3:
				  positionName = "3���";
				  break;
			  case 4:
				  positionName = "���ݼ�";
				  break;
			  case 5:
				  positionName = "���ͼ�";
				  break;
			  case 6:
				  positionName = "�߰߼�";
				  break;
			  case 7:
				  positionName = "���ͼ�";
				  break;
			  case 8:
				  positionName = "����Ÿ��";
				  
			  
			  }
		  
		  System.out.println("| "+StartMember[j].BackNum+" | "+StartMember[j].name+" | "+positionName+" |");
		  }
		}
		else{
			crawlmodule.Crawl();
			infoget.getinformation();
	
			
			for(int i = 0; i<25; i++) {
			batters[i] = new Vertex(i,infoget.battername[i],infoget.batterposition[i]);
			
			
			}
			while(true) {
			System.out.println("������� ��������� �˷��ֽʽÿ�.(0:���,1:KT,2:LG,3:NC,4:SK,5:�ؼ�,6:�λ�,7:�Ե�,8:�Ｚ)");
			 OppoTeam = s.nextInt();
			
			
			if(OppoTeam >8) {
				System.out.println("8�� �ȿ����� ������ ����ֽʽÿ�");
				OppoTeam = s.nextInt();
				break;
				
			}
			else {
				break;
			}
			}
			
			for(int i = 0; i< 25; i++) {
				for(int j = 0; j<25; j++) {
					edges[i][j]= new Edge(infoget.avHitarr[i][OppoTeam],infoget.OPSarr[i][OppoTeam],infoget.WPAarr[i][OppoTeam]);
					
					if(batters[i].position==batters[j].position) {
							edges[i][j].setConnection(batters[i], null);
						
					}
					else {
							edges[i][j].setConnection(batters[i], batters[j]);
					}
					
					
				}
			}
			
			
		  for(int p = 0; p< 9; p++) {
			  while(true) {
			  System.out.println((p+1)+"�� Ÿ�ڸ� ���� ���� �켱�ؾ� �� �����͸� �˷��ֽʽÿ�(1:�����,2:OPS,3:WPA)");
			  data = s.nextInt();
			  
			  if(data>3&&data<1) {
				  System.out.println("1,2,3�� ���� ���ڸ� �Է����ֽʽÿ�");
				  data=s.nextInt();
				  break;
			  }
			  else {
				  break;
			  }
			  
			  
			  }
			  if(data==1) {
				  double MaxavHit = 0.0;
				  int selectednum = -1;
				  for(int f = 0; f<25; f++) {
					  
						  if(selectedposition[batters[f].position]==-1) {
							  if(MaxavHit<edges[f][0].getWeight1()) {
								  MaxavHit = edges[f][0].getWeight1();
								  selectednum = f;
							  }
						  
						  
					  }
						
						
				  }
				  
				  StartMember[p]=batters[selectednum];
				  selectedposition[batters[selectednum].position]=1;
				  for(int f = 0; f<25; f++) {
					  
					  if(selectedposition[batters[f].position]==-1) {
						System.out.print("B ");
					  
					  
				  }
					  else if(selectednum ==f) {
						  System.out.print("S ");
					  }
					  else {
						  System.out.print("  ");
					  }
					if((f+1)%5==0) {
						System.out.println();
					}
					
			  }
				
				  
				  
			  }
			  else if(data==2) {
				  double OPS = 0.0;
				  int selectednum = -1;
				  for(int f = 0; f<25; f++) {
					  
						  if(selectedposition[batters[f].position]==-1) {
							  if(OPS<edges[f][0].getWeight2()) {
								  OPS = edges[f][0].getWeight2();
								  selectednum = f;
							  }
						  
						  
					  }
						
						
				  }
				  
				  StartMember[p]=batters[selectednum];
				  selectedposition[batters[selectednum].position]=1;
				  for(int f = 0; f<25; f++) {
					  
					  if(selectedposition[batters[f].position]==-1) {
						System.out.print("B ");
					  
					  
				  }
					  else if(selectednum ==f) {
						  System.out.print("S ");
					  }
					  else {
						  System.out.print("  ");
					  }
					if((f+1)%5==0) {
						System.out.println();
					}
					
			  }
				
				  
				  
			  }
			  else if(data==3) {
				  double WPA = -100.0;
				  int selectednum = -1;
				  for(int f = 0; f<25; f++) {
					  
						  if(selectedposition[batters[f].position]==-1) {
							  if(WPA<edges[f][0].getWeight3()) {
								  WPA = edges[f][0].getWeight3();
								  selectednum = f;
							  }
						  
						  
					  }
						
						
				  }
				  
				  StartMember[p]=batters[selectednum];
				  selectedposition[batters[selectednum].position]=1;
				  for(int f = 0; f<25; f++) {
					  
					  if(selectedposition[batters[f].position]==-1) {
						System.out.print("B ");
					  
					  
				  }
					  else if(selectednum ==f) {
						  System.out.print("S ");
					  }
					  else {
						  System.out.print("  ");
					  }
					if((f+1)%5==0) {
						System.out.println();
					}
					
			  }
				  
			  }
			
		  }
		  
		
		  System.out.println("| ���ȣ | ���� �̸� | ���� ������ |");
		  
		  for(int j = 0; j<9; j++) {
			  String positionName = null;
			  switch(StartMember[j].position) {
			  case 0:
				  positionName = "����";
				  break;
			  case 1:
				  positionName = "1���";
				  break;
			  case 2:
				  positionName = "2���";
				  break;
			  case 3:
				  positionName = "3���";
				  break;
			  case 4:
				  positionName = "���ݼ�";
				  break;
			  case 5:
				  positionName = "���ͼ�";
				  break;
			  case 6:
				  positionName = "�߰߼�";
				  break;
			  case 7:
				  positionName = "���ͼ�";
				  break;
			  case 8:
				  positionName = "����Ÿ��";
				  
			  
			  }
		  
		  System.out.println("| "+StartMember[j].BackNum+" | "+StartMember[j].name+" | "+positionName+" |");
		  }
			
		}
		
		
		
		
		
		
	
		
		

	}

}
