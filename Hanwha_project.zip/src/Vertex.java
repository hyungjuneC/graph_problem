
public class Vertex {
	int BackNum = -1;
	
	int nextNum = -1;
	
	int prevNum = -1;
	
	double avHit = 0.0;
	
	double OPS = 0.0;
	
	double WAR = 0.0;
	
	
	
	Vertex(int Backnum ,double avhit,double ops,double war){
		
		this.BackNum= Backnum;
		
		this.avHit = avhit;
		
		this.OPS = ops;
		
		this.WAR= war;
		
	}

}
