
public class Edges {

}
